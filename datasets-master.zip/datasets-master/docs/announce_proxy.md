# Introducing TensorFlow Datasets

TensorFlow Datasets is now released on PyPI:

`pip install tensorflow-datasets`

Read the [blog post](https://medium.com/tensorflow/introducing-tensorflow-datasets-c7f01f7e19f3)
to learn more.
